import asyncio
import pygame
from pathlib import Path
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent/'src'))
from minegame.app import run, run_native

if sys.platform == 'emscripten':
    asyncio.run(run())
else:
    run_native()
