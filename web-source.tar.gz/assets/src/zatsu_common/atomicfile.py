"""Replace one local text file through a flushed temporary sibling file.

This is a file-writing primitive, not a transaction or browser storage layer.
It supplies no cross-process locking, schema validation, backup, or merge.
"""
import os
from pathlib import Path
import uuid


def atomic_write_text(target: str | os.PathLike[str], content: str) -> None:
    """Write UTF-8 text with LF newlines and replace target after flush/fsync.

    The parent directory must already exist. Errors propagate to the caller;
    before a successful replace, the old target is preserved. Temporary files
    created by this call are cleaned up when possible. No claim is made about
    directory durability after power loss, permissions preservation, or network
    filesystem semantics. Use a dedicated, trusted save directory.
    """
    if not isinstance(content, str):
        raise TypeError('content must be str')
    target = Path(target)
    temporary = target.with_name(target.name + '.' + uuid.uuid4().hex + '.tmp')
    created = False
    try:
        with temporary.open('x', encoding='utf-8', newline='\n') as stream:
            created = True
            stream.write(content)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, target)
    finally:
        # Do not remove a pre-existing file if exclusive creation failed.
        if created:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass  # Preserve the original write/replace exception, if any.
