"""Fixed common atomicfile component 1.0.0; see docs/reuse."""
