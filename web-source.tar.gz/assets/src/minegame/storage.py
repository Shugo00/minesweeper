"""Local records, explicit failures, and idempotent save retries."""
from datetime import datetime
import json
from pathlib import Path
from .topology import BY_KEY
from zatsu_common.atomicfile import atomic_write_text

AUDIO_DEFAULTS={'se_volume':30,'bgm_volume':20,'se_muted':False,'bgm_muted':False}

def empty_state():
    return {'schema':1,'settings':{'board':'beginner','control':'mouse',**AUDIO_DEFAULTS},'records':[]}


def validate(state):
    if not isinstance(state,dict) or type(state.get('schema')) is not int or state['schema']!=1:
        raise ValueError('記録の形式または版を読み取れない')
    settings=state.get('settings')
    if not isinstance(settings,dict) or settings.get('board') not in BY_KEY or settings.get('control') not in ('mouse','switch'):
        raise ValueError('設定の形式を読み取れない')
    settings={**AUDIO_DEFAULTS,**settings}
    for kind in ('se','bgm'):
        value=settings[kind+'_volume']
        if type(value) is not int or not 0<=value<=100 or type(settings[kind+'_muted']) is not bool:
            raise ValueError('音量またはミュート設定が不正')
    records=state.get('records')
    if not isinstance(records,list) or len(records)>100: raise ValueError('記録件数が不正')
    ids=set()
    for r in records:
        if not isinstance(r,dict) or r.get('board') not in BY_KEY: raise ValueError('盤面の記録が不正')
        if not isinstance(r.get('id'),str) or not r['id'] or r['id'] in ids: raise ValueError('記録IDが不正')
        ids.add(r['id'])
        for key in ('time','hints'):
            if type(r.get(key)) is not int or r[key]<0: raise ValueError('時間・ヒント回数が不正')
        if not isinstance(r.get('date'),str): raise ValueError('日時が不正')
        if datetime.fromisoformat(r['date']).tzinfo is None: raise ValueError('日時に時差がない')
    return {**state,'settings':settings}


def rank(records):
    unique={}
    for r in records: unique.setdefault(r['id'],r)
    result=[]
    for key in BY_KEY:
        for hints in (False,True):
            group=[r for r in unique.values() if r['board']==key and bool(r['hints'])==hints]
            result.extend(sorted(group,key=lambda r:r['time'])[:10])
    return result


class FileStore:
    def __init__(self, path): self.path=Path(path)

    def read(self):
        if not self.path.exists(): return empty_state()
        return validate(json.loads(self.path.read_text(encoding='utf-8')))

    def write(self, state):
        state=validate(state)
        self.path.parent.mkdir(parents=True,exist_ok=True)
        atomic_write_text(self.path,json.dumps(state,ensure_ascii=False,indent=2)+'\n')


class WebStore:
    KEY='zatsu.minesweeper.v1'

    def read(self):
        from .platforms import js_value
        result=js_value('(() => {try{return {ok:true,value:localStorage.getItem("'+self.KEY+'")};}catch(e){return {ok:false};}})()')
        if not result['ok']: raise OSError('ブラウザの保存領域を読み取れない')
        return validate(json.loads(result['value'])) if result['value'] is not None else empty_state()

    def write(self, state):
        from .platforms import js_value
        state=validate(state)
        data=json.dumps(json.dumps(state,ensure_ascii=True))
        result=js_value('(() => {try{localStorage.setItem("'+self.KEY+'",'+data+');return true;}catch(e){return false;}})()')
        if not result: raise OSError('ブラウザの保存領域へ書き込めない')


class SaveManager:
    def __init__(self, store):
        self.store=store;self.pending=[];self.error='';self.settings_dirty=False
        try: self.state=store.read()
        except (OSError,ValueError,TypeError,KeyError) as exc:
            self.state=empty_state();self.error=str(exc)

    def save(self, settings=None, record=None):
        if settings is not None:
            self.state['settings']=dict(settings);self.settings_dirty=True
        if record and all(r['id']!=record['id'] for r in self.pending): self.pending.append(record)
        try:
            latest=self.store.read()  # Never overwrite unknown/corrupted existing data.
            if self.settings_dirty: latest['settings']=dict(self.state['settings'])
            latest['records']=rank(latest['records']+self.pending)
            latest=validate(latest)
            self.store.write(latest)
            self.state=latest;self.pending=[];self.error='';self.settings_dirty=False
            return True
        except (OSError,ValueError,TypeError,KeyError) as exc:
            self.error=str(exc);return False

    def records(self, board, assisted):
        return [r for r in self.state['records'] if r['board']==board and bool(r['hints'])==assisted]
