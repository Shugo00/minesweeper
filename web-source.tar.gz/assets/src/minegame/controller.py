from .hints import find_hint


class Session:
    def __init__(self, game):
        self.game = game
        self.accumulated = 0
        self.since = None
        self.paused = False
        self.hint_count = 0
        self.hint = None
        self.message = '最初のマスを開くと計時が始まる．初手にも地雷がある．'

    def centiseconds(self, now):
        ns = self.accumulated + (max(0,now-self.since) if self.since is not None else 0)
        return ns // 10_000_000

    def open(self, cell, now):
        if self.paused or not self.game.can_open(cell): return False
        if self.game.state == 'ready': self.since = now
        changed = self.game.open(cell)
        self.hint = None
        self.message = ''
        if self.game.finished: self.stop(now)
        return changed

    def flag(self, cell):
        if self.paused: return False
        changed=self.game.flag(cell)
        if changed: self.hint=None; self.message=''
        return changed

    def stop(self, now):
        if self.since is not None:
            self.accumulated += max(0,now-self.since)
            self.since = None

    def pause(self, now):
        if self.game.state not in ('ready','playing') or self.paused: return
        self.stop(now);self.paused=True

    def resume(self, now):
        if self.paused:
            self.paused=False
            # Music can resume before the first open; the timer must not.
            if self.game.state=='playing':self.since=now

    def request_hint(self):
        if self.paused or self.game.state!='playing': return None
        self.hint=find_hint(self.game.public())
        if self.hint:
            self.hint_count+=1;self.message=self.hint.reason
        else: self.message='このヒントでは判断できない．別の数字に注目してみよう．'
        return self.hint


def format_time(cs):
    return f'{cs//6000:02d}:{cs//100%60:02d}.{cs%100:02d}'
