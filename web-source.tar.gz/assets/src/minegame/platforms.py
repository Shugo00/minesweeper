"""OS/Web boundary. Focus-cover pattern adapted from common R-004 reference."""
from datetime import datetime
import json
import os
from pathlib import Path
import sys
import time

WEB = sys.platform == 'emscripten'


def js_eval(source):
    from platform import window
    return window.eval('eval('+json.dumps(source,ensure_ascii=True)+')')


def js_value(expression):
    return json.loads(str(js_eval('JSON.stringify('+expression+r''').replace(/[\u007f-\uffff]/g,c=>String.fromCharCode(92)+'u'+c.charCodeAt(0).toString(16).padStart(4,'0'))''')))


class Platform:
    def __init__(self):
        if WEB:
            js_eval('''(() => {
                const cover=document.createElement('div');
                cover.style.cssText='position:fixed;inset:0;background:#f2f4f4;color:#202a30;z-index:2147483647;display:none;padding:40px;font:24px sans-serif';
                cover.textContent='一時停止';document.body.appendChild(cover);
                const hook=window.__minesweeperFocus={active:false,lost:null,cover};
                const pause=()=>{if(hook.active){if(hook.lost===null)hook.lost=performance.now();cover.style.display='block';}};
                window.addEventListener('blur',pause);
                document.addEventListener('visibilitychange',()=>{if(document.hidden)pause();});
                const canvas=document.getElementById('canvas');
                if(canvas){canvas.addEventListener('contextmenu',e=>e.preventDefault());canvas.style.touchAction='manipulation';}
                return true;
            })()''')

    def now(self):
        return int(float(js_eval('performance.now()'))*1_000_000) if WEB else time.perf_counter_ns()

    def stamp(self):
        # ISO UTC is unambiguous and is formatted locally for the record table.
        return str(js_eval('new Date().toISOString()')) if WEB else datetime.now().astimezone().isoformat(timespec='seconds')

    def store(self):
        from .storage import FileStore,WebStore
        if WEB:return WebStore()
        folder=Path(os.environ.get('MINESWEEPER_DATA_DIR',str(Path(os.environ.get('LOCALAPPDATA',Path.home()))/'ZatsuGames/Minesweeper')))
        return FileStore(folder/'state-v1.json')

    def active(self, value):
        if WEB:js_eval('window.__minesweeperFocus.active='+str(bool(value)).lower())

    def focused(self):
        return bool(js_value('!document.hidden && document.hasFocus()')) if WEB else True

    def audio_lost(self):
        if not WEB:return False
        return bool(js_eval('''(() => {if(!window.__mineAudio?.lost)return false;
            window.__mineAudio.lost=false;return true;})()'''))

    def lost_at(self):
        if not WEB:return None
        value=js_value('window.__minesweeperFocus.lost')
        if value is not None:
            js_eval('window.__minesweeperFocus.lost=null')
            return int(value*1_000_000)
        return None

    def painted(self):
        if WEB:js_eval("window.__minesweeperFocus.cover.style.display='none'")

    def size(self, native):
        if not WEB:return native
        return tuple(js_value('[Math.max(1,window.innerWidth),Math.max(1,window.innerHeight)]'))
