from dataclasses import dataclass
import random


@dataclass(frozen=True)
class PublicBoard:
    neighbors: tuple
    numbers: tuple  # None for hidden cells; never includes their mine counts.
    flags: frozenset


class Game:
    def __init__(self, topology, mines=None, rng=None):
        self.topology = topology
        n = len(topology.cells)
        self.mines = frozenset((rng or random.Random()).sample(range(n),topology.spec.mines) if mines is None else mines)
        if len(self.mines)!=topology.spec.mines or not self.mines <= set(range(n)):
            raise ValueError('Invalid mine placement')
        self.numbers = tuple(len(adj & self.mines) for adj in topology.neighbors)
        self.opened = set()
        self.flags = set()
        self.state = 'ready'
        self.exploded = None

    @property
    def finished(self):
        return self.state in ('won','lost')

    def can_open(self, cell):
        return not self.finished and cell in range(len(self.numbers)) and cell not in self.flags | self.opened

    def open(self, cell):
        if not self.can_open(cell): return False
        self.state = 'playing'
        if cell in self.mines:
            self.exploded = cell; self.state = 'lost'
            return True
        queue = [cell]
        while queue:
            current = queue.pop()
            if current in self.opened or current in self.flags: continue
            self.opened.add(current)
            if self.numbers[current] == 0:
                queue.extend(self.topology.neighbors[current] - self.opened - self.flags)
        if len(self.opened) == len(self.numbers)-len(self.mines): self.state = 'won'
        return True

    def flag(self, cell):
        if self.finished or cell not in range(len(self.numbers)) or cell in self.opened: return False
        if cell in self.flags: self.flags.remove(cell)
        else: self.flags.add(cell)
        return True

    def public(self):
        return PublicBoard(self.topology.neighbors,tuple(n if i in self.opened else None for i,n in enumerate(self.numbers)),frozenset(self.flags))
