"""Bounded deduction from public clues only. Player flags are not axioms."""
from dataclasses import dataclass


@dataclass(frozen=True)
class Hint:
    cell: int
    action: str
    clues: frozenset
    reason: str


def find_hint(public):
    unknown = frozenset(i for i,n in enumerate(public.numbers) if n is None)
    constraints = {}
    for i,n in enumerate(public.numbers):
        if n is not None:
            cells = public.neighbors[i] & unknown
            if cells: constraints[(cells,n)] = frozenset({i})
    safe, mines = {}, {}
    for _ in range(16):
        before = (len(safe),len(mines),len(constraints))
        reduced = {}
        for (cells,n),proof in constraints.items():
            known_mines = cells & mines.keys()
            known_safe = cells & safe.keys()
            for cell in known_mines: proof |= mines[cell]
            for cell in known_safe: proof |= safe[cell]
            cells = cells - known_mines - known_safe
            n -= len(known_mines)
            if n < 0 or n > len(cells): return None  # inconsistent public data
            if not cells: continue
            if n == 0:
                for cell in cells: safe[cell] = proof
            elif n == len(cells):
                for cell in cells: mines[cell] = proof
            else: reduced[(frozenset(cells),n)] = proof
        if safe:
            cell=min(safe)
            extra='先にこのマスの旗を外してから開ける．' if cell in public.flags else 'このマスは安全に開ける．'
            return Hint(cell,'safe',safe[cell],'枠で示した数字の条件を比べると，このマスに地雷は入らない．'+extra)
        candidates = set(mines)-public.flags
        if candidates:
            cell=min(candidates)
            return Hint(cell,'mine',mines[cell],'枠で示した数字を満たすには，このマスが地雷になる．旗を置ける．')
        constraints = reduced
        pairs = list(reduced.items())
        for (a,na),pa in pairs:
            for (b,nb),pb in pairs:
                if a < b:
                    difference=b-a
                    constraints.setdefault((difference,nb-na),pa|pb)
                    if len(constraints)>=1024: break
            if len(constraints)>=1024: break
        if before == (len(safe),len(mines),len(constraints)): break
    return None
