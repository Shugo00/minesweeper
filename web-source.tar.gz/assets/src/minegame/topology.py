"""One immutable geometry/adjacency description for drawing, input and rules."""
from dataclasses import dataclass
from math import sqrt, cos, sin, pi


@dataclass(frozen=True)
class BoardSpec:
    key: str
    name: str
    mines: int
    shape: str
    width: int = 0
    height: int = 0


SPECS = (
    BoardSpec('beginner', '通常・初級', 10, 'square', 9, 9),
    BoardSpec('intermediate', '通常・中級', 40, 'square', 16, 16),
    BoardSpec('expert', '通常・上級', 99, 'square', 30, 16),
    BoardSpec('hex', 'エクストラ・六角形', 15, 'hex'),
    BoardSpec('triangle', 'エクストラ・三角形', 15, 'triangle'),
)
BY_KEY = {s.key: s for s in SPECS}


@dataclass(frozen=True)
class Cell:
    vertices: tuple
    center: tuple
    row: int


@dataclass(frozen=True)
class Topology:
    spec: BoardSpec
    cells: tuple
    neighbors: tuple

    def move(self, current, dx, dy):
        cell = self.cells[current]
        row = cell.row + dy
        candidates = [i for i, c in enumerate(self.cells) if c.row == row]
        if dx:
            candidates = [i for i in candidates if (self.cells[i].center[0] - cell.center[0]) * dx > 1e-8]
        if not candidates:
            return current
        return min(candidates, key=lambda i: (abs(self.cells[i].center[0] - cell.center[0]), i))

    def fit(self, rect):
        x, y, width, height = rect
        points = [p for c in self.cells for p in c.vertices]
        minx, maxx = min(p[0] for p in points), max(p[0] for p in points)
        miny, maxy = min(p[1] for p in points), max(p[1] for p in points)
        scale = min(width / (maxx - minx), height / (maxy - miny))
        ox = x + (width - (maxx - minx) * scale) / 2 - minx * scale
        oy = y + (height - (maxy - miny) * scale) / 2 - miny * scale
        return tuple(tuple((ox + px * scale, oy + py * scale) for px, py in c.vertices) for c in self.cells)


def center(points):
    return tuple(sum(p[k] for p in points) / len(points) for k in (0, 1))


def hit(polygons, point):
    x, y = point
    for i, poly in enumerate(polygons):
        crosses = [(b[0]-a[0])*(y-a[1])-(b[1]-a[1])*(x-a[0]) for a,b in zip(poly, poly[1:]+poly[:1])]
        if min(crosses) >= -1e-7 or max(crosses) <= 1e-7:
            return i
    return None


def make_topology(spec):
    cells, coords, vertices = [], [], []
    if spec.shape == 'square':
        for y in range(spec.height):
            for x in range(spec.width):
                p = ((x,y),(x+1,y),(x+1,y+1),(x,y+1))
                cells.append(Cell(p, center(p), y)); coords.append((x,y))
        lookup = {p:i for i,p in enumerate(coords)}
        neighbors = [frozenset(lookup[(x+dx,y+dy)] for dx in (-1,0,1) for dy in (-1,0,1)
                               if (dx or dy) and (x+dx,y+dy) in lookup) for x,y in coords]
    elif spec.shape == 'hex':
        for r in range(-5,6):
            for q in range(max(-5,-r-5),min(5,-r+5)+1):
                x,y = sqrt(3)*(q+r/2),1.5*r
                p = tuple((x+cos((60*i-30)*pi/180),y+sin((60*i-30)*pi/180)) for i in range(6))
                cells.append(Cell(p,(x,y),r)); coords.append((q,r))
        lookup = {p:i for i,p in enumerate(coords)}
        directions = ((1,0),(-1,0),(0,1),(0,-1),(1,-1),(-1,1))
        neighbors = [frozenset(lookup[(q+dq,r+dr)] for dq,dr in directions if (q+dq,r+dr) in lookup) for q,r in coords]
    elif spec.shape == 'triangle':
        for r in range(10):
            for j in range(r+1):
                x=2*j-r
                row = [((x,r),(x+1,r+1),(x-1,r+1))]
                if j<r: row.append(((x,r),(x+2,r),(x+1,r+1)))
                for raw in row:
                    p=tuple((a/2,b*sqrt(3)/2) for a,b in raw)
                    vertices.append(frozenset(raw));cells.append(Cell(p,center(p),r))
        neighbors = [frozenset(j for j,b in enumerate(vertices) if i!=j and a & b) for i,a in enumerate(vertices)]
    else:
        raise ValueError('Unknown board shape')
    return Topology(spec,tuple(cells),tuple(neighbors))
