"""pygame UI. Rules, reasoning, elapsed time and storage live in separate modules."""
import asyncio
from datetime import datetime
import os
from pathlib import Path
import sys
import uuid
import json
import pygame
from .controller import Session,format_time
from .model import Game
from .platforms import Platform,WEB,js_eval
from .storage import SaveManager
from .audio import Audio
from .topology import SPECS,BY_KEY,BoardSpec,make_topology,center,hit

ROOT=Path(getattr(sys,'_MEIPASS',Path(__file__).resolve().parents[2]))
BG=(242,244,244);PANEL=(250,251,251);INK=(32,42,48);MUTED=(73,91,101)
CELL=(209,218,221);EDGE=(125,145,157);OPEN=(236,240,240);TEAL=(36,76,82)
GOLD=(175,109,18);RED=(163,42,44);GREEN=(32,103,66)
NUMBERS={1:(33,83,162),2:(38,113,62),3:(172,48,53),4:(92,57,145),5:(143,65,28),6:(24,119,125)}


class App:
    def __init__(self,platform=None,audio=None):
        pygame.display.init();pygame.font.init()
        pygame.display.set_caption('マインスイーパー')
        self.window=pygame.display.set_mode((1000,720),pygame.RESIZABLE)
        self.platform=platform or Platform()
        self.saves=SaveManager(self.platform.store())
        self.settings=dict(self.saves.state['settings'])
        self.audio=audio if audio is not None else Audio(ROOT/'assets/audio',self.settings)
        self.audio_return=('setup','audio');self.audio_preview=False;self.window_focused=True
        self.topologies={s.key:make_topology(s) for s in SPECS}
        self.screen='setup';self.return_screen='setup';self.dropdown=False
        self.session=None;self.flag_mode=False;self.selected=0;self.focus='board'
        self.game_id='';self.recorded=False;self.record_message=''
        self.record_board=self.settings['board'];self.assisted=False
        self.buttons=[];self.polygons=();self.fonts={};self.running=True
        self.tutorial=None;self.tutorial_step=0
        self.last_transform=(1,0,0)
        self.now=self.platform.now()
        self.check_mode=WEB and bool(js_eval('new URLSearchParams(location.search).has("check")'))
        self.draw()

    def font(self,size):
        size=max(12,int(size))
        if size not in self.fonts:self.fonts[size]=pygame.font.Font(str(ROOT/'assets/NotoSansCJKjp-Regular.otf'),size)
        return self.fonts[size]

    def text(self,content,pos,size=18,color=INK,align='left'):
        image=self.font(size).render(str(content),True,color)
        rect=image.get_rect();setattr(rect,{'left':'topleft','center':'midtop','right':'topright'}[align],pos)
        self.canvas.blit(image,rect)
        return rect

    def paragraph(self,content,rect,size=17,color=INK):
        x,y,w,h=rect;line='';step=size+8
        for ch in content:
            if ch=='\n' or self.font(size).size(line+ch)[0]>w:
                if y+step>rect[1]+h:return
                self.text(line,(x,y),size,color);y+=step;line=''
                if ch=='\n':continue
            line+=ch
        if line and y+step<=rect[1]+h:self.text(line,(x,y),size,color)

    def button(self,key,label,rect,action,enabled=True,primary=False):
        rect=pygame.Rect(rect)
        pygame.draw.rect(self.canvas,TEAL if primary else PANEL,rect,border_radius=5)
        pygame.draw.rect(self.canvas,EDGE,rect,1,border_radius=5)
        if enabled and key==self.focus:pygame.draw.rect(self.canvas,GOLD,rect.inflate(4,4),2,border_radius=6)
        self.text(label,(rect.centerx,rect.y+9),17,(255,255,255) if primary else INK if enabled else (145,153,158),'center')
        self.buttons.append((key,rect,action,enabled))

    def row(self,items,y):
        widths=[max(88,self.font(17).size(label)[0]+28) for _,label,_,_,_ in items]
        x=(self.W-sum(widths)-8*(len(items)-1))/2
        for (key,label,action,enabled,primary),width in zip(items,widths):
            self.button(key,label,(x,y,width,44),action,enabled,primary);x+=width+8

    def transition(self,screen,focus='board'):
        self.screen=screen;self.focus=focus;self.buttons=[];self.polygons=();self.dropdown=False
        if screen!='play':self.audio.suspend()

    def choose_board(self,key):
        self.settings['board']=key;self.dropdown=False

    def switch_control(self):
        self.settings['control']='switch' if self.settings['control']=='mouse' else 'mouse'

    def start(self):
        self.audio.new_game()
        self.saves.save(settings=self.settings)
        self.session=Session(Game(self.topologies[self.settings['board']]))
        self.game_id=uuid.uuid4().hex;self.recorded=False;self.record_message=''
        self.selected=0;self.flag_mode=False;self.transition('play')

    def show_rules(self):
        self.return_screen=self.screen
        if self.screen=='play':self.session.pause(self.now)
        self.transition('rules','back')

    def show_records(self):
        self.return_screen=self.screen;self.record_board=self.settings['board']
        self.transition('records','record-board')

    def back(self):
        if self.return_screen=='play':self.return_to_play()
        else:self.transition(self.return_screen)

    def return_to_play(self):
        self.transition('play','resume' if self.session.paused else 'board')

    def leave(self):
        if self.screen=='play' and not self.session.game.finished and (self.session.game.opened or self.session.game.flags):
            self.session.pause(self.now);self.transition('confirm','cancel')
        else:self.transition('setup','start')

    def close_request(self):
        under=self.audio_return[0] if self.screen=='audio' else self.screen
        in_game = under in ('play','confirm','quit') or (under=='rules' and self.return_screen=='play')
        if in_game and self.session and not self.session.game.finished and (self.session.game.opened or self.session.game.flags):
            self.session.pause(self.now);self.transition('quit','cancel')
        else:self.running=False

    def pause(self):
        self.session.pause(self.now)
        self.audio.suspend()
        if self.session.paused:self.focus='resume'
    def resume(self):self.session.resume(self.now);self.focus='board'
    def toggle_flag(self):self.flag_mode=not self.flag_mode

    def check_result(self):
        if self.session.game.state=='won' and not self.recorded:
            self.recorded=True
            record={'id':self.game_id,'board':self.settings['board'],'date':self.platform.stamp(),
                    'time':self.session.centiseconds(self.now),'hints':self.session.hint_count}
            self.saves.save(record=record)
            self.record_message='クリア記録を保存した．' if not self.saves.error else 'クリアしたが，記録は未保存．再試行できる．'

    def retry_save(self):
        if self.saves.save():self.record_message='記録・設定を保存した．'

    def hint(self):
        if self.session.paused or self.session.game.state!='playing':return
        result=self.session.request_hint()
        self.audio.effect('hint' if result else 'notice')

    def open_cell(self,cell,flag=False):
        if self.screen=='tutorial':
            if self.tutorial_step==0 and cell==6 and not flag:
                self.tutorial.open(cell);self.tutorial_step=1
                self.audio.effect('open')
            elif self.tutorial_step==2 and cell==12 and flag:
                self.tutorial.flag(cell);self.tutorial_step=3
                self.audio.effect('flag_on')
            elif self.tutorial_step==3 and cell==12 and flag:
                self.tutorial.flag(cell);self.tutorial_step=4
                self.audio.effect('flag_off')
            return
        if self.screen!='play':return
        if flag:
            if self.session.flag(cell):
                self.audio.effect('flag_on' if cell in self.session.game.flags else 'flag_off')
        elif self.session.open(cell,self.now):
            outcome={'won':'win','lost':'lose'}.get(self.session.game.state,'open')
            self.audio.effect(outcome)
        self.check_result()

    def begin_tutorial(self):
        self.tutorial=Game(make_topology(BoardSpec('tutorial','練習',1,'square',5,5)),{12})
        self.tutorial_step=0;self.flag_mode=False;self.selected=6;self.transition('tutorial')

    def next_tutorial(self):self.tutorial_step=2;self.selected=12

    def show_audio(self):
        self.audio_return=(self.screen,self.focus)
        if self.screen=='play':self.session.pause(self.now)
        self.audio_preview=False;self.transition('audio','se-down')

    def back_audio(self):
        self.audio_preview=False
        screen,focus=self.audio_return
        if screen=='play':self.return_to_play()
        else:self.transition(screen,focus)

    def change_audio(self,kind,delta=None):
        if delta is None:
            key=kind+'_muted';self.settings[key]=not self.audio.settings[key]
        else:
            key=kind+'_volume';self.settings[key]=max(0,min(100,self.audio.settings[key]+delta))
        self.audio.configure(self.settings)
        self.saves.save(settings=self.settings)

    def preview_music(self):self.audio_preview=not self.audio_preview

    def draw_audio(self):
        self.audio.poll_error()
        self.text('音の設定',(30,88),26)
        self.text('SEとBGMを別々に調整できる．変更は自動で保存する．',(30,136),17,MUTED)
        for kind,label,y in [('se','SE・効果音',208),('bgm','BGM・音楽',326)]:
            volume=self.audio.settings[kind+'_volume'];muted=self.audio.settings[kind+'_muted']
            self.text(label,(40,y),22)
            self.text(f'{volume}%',(250,y),24,align='center')
            self.button(kind+'-down','−',(310,y-5,60,44),lambda k=kind:self.change_audio(k,-10),volume>0)
            self.button(kind+'-up','＋',(382,y-5,60,44),lambda k=kind:self.change_audio(k,10),volume<100)
            self.button(kind+'-mute','ミュート中' if muted else '音あり',(460,y-5,126,44),lambda k=kind:self.change_audio(k),primary=muted)
            self.button(kind+'-preview','試聴を止める' if kind=='bgm' and self.audio_preview else '試聴',
                        (604,y-5,152,44),self.preview_music if kind=='bgm' else lambda:self.audio.effect('open'))
        self.paragraph('ミュート中・音量0%では試聴も無音になる．BGMはプレイ中に流れ，一時停止・説明・離席中は止まる．',
                       (40,402,self.W-80,65),16,MUTED)
        error=self.audio.error or self.audio.bgm_error
        if error:
            self.text(error,(40,478),16,RED)
            self.button('audio-retry','音声を再試行',(self.W-204,467,164,44),lambda:self.audio.unlock(retry=True))
        self.button('audio-back','戻る',(self.W/2-70,self.H-65,140,44),self.back_audio,primary=True)

    def draw_board(self,topology,rect,game=None,show_focus=False,highlight=None):
        polygons=topology.fit(rect)
        self.polygons=polygons
        hint=self.session.hint if self.screen=='play' and self.session else None
        for i,poly in enumerate(polygons):
            cx,cy=center(poly)
            edges=[((b[0]-a[0])**2+(b[1]-a[1])**2)**.5 for a,b in zip(poly,poly[1:]+poly[:1])]
            size=min(edges)
            shrink=max(.89,1-1.8/max(1,size))
            inner=[(cx+(x-cx)*shrink,cy+(y-cy)*shrink) for x,y in poly]
            opened=game is not None and i in game.opened
            mine_visible=game and game.finished and i in game.mines
            fill=OPEN if opened else CELL
            if game and game.exploded==i:fill=(243,194,187)
            pygame.draw.polygon(self.canvas,fill,inner)
            pygame.draw.polygon(self.canvas,EDGE,inner,1)
            if opened and game.numbers[i]:
                value=game.numbers[i]
                font_size=max(12,min(25,int(size*(.43 if topology.spec.shape=='triangle' else .58))))
                self.text(value,(cx,cy-font_size*.7),font_size,NUMBERS.get(value,INK),'center')
            elif mine_visible:
                # A hexagon's short edge understates the room available for its mine.
                mine_size=(min(max(x for x,y in poly)-min(x for x,y in poly),
                               max(y for x,y in poly)-min(y for x,y in poly))
                           if topology.spec.shape=='hex' else size)
                radius=max(3,int(mine_size*.17));pygame.draw.circle(self.canvas,RED if i==game.exploded else INK,(cx,cy),radius)
                pygame.draw.line(self.canvas,INK,(cx-radius*1.5,cy),(cx+radius*1.5,cy),1)
                pygame.draw.line(self.canvas,INK,(cx,cy-radius*1.5),(cx,cy+radius*1.5),1)
            elif game and i in game.flags:
                unit=min(14,size*.24)
                pygame.draw.line(self.canvas,INK,(cx-unit*.5,cy-unit),(cx-unit*.5,cy+unit),2)
                pygame.draw.polygon(self.canvas,RED,[(cx-unit*.5,cy-unit),(cx+unit*.85,cy-unit*.35),(cx-unit*.5,cy+.1*unit)])
                pygame.draw.line(self.canvas,INK,(cx-unit,cy+unit),(cx+unit*.5,cy+unit),2)
                if game.finished and i not in game.mines:
                    pygame.draw.line(self.canvas,RED,(cx-unit,cy-unit),(cx+unit,cy+unit),2)
                    pygame.draw.line(self.canvas,RED,(cx-unit,cy+unit),(cx+unit,cy-unit),2)
            if hint and i in hint.clues:pygame.draw.polygon(self.canvas,(42,107,156),inner,2)
            if show_focus and self.focus=='board' and i==self.selected:pygame.draw.polygon(self.canvas,TEAL,inner,3)
            # Keep the guidance color visible when its cell is also keyboard-selected.
            if (hint and i==hint.cell) or i==highlight:pygame.draw.polygon(self.canvas,GOLD,inner,3)
        return polygons

    def draw_setup(self):
        w=self.W
        self.text('ゲームを選ぶ',(28,92),23)
        self.text('盤面',(28,144),17)
        self.button('board-choice',BY_KEY[self.settings['board']].name+'  選択',(28,174,264,44),lambda:setattr(self,'dropdown',not self.dropdown))
        self.text('操作方式',(28,242),17)
        control='左右クリック式' if self.settings['control']=='mouse' else '旗スイッチ式'
        self.button('control',control+'  ⇄',(28,272,264,44),self.switch_control)
        desc='左クリックで開く\n右クリックで旗を付け外し' if self.settings['control']=='mouse' else 'OFF：クリック・タップで開く\nON：クリック・タップで旗'
        self.paragraph(desc,(28,334,276,70),17,MUTED)
        self.button('start','はじめる',(28,420,264,46),self.start,primary=True)
        self.button('rules','遊び方',(28,482,82,44),self.show_rules)
        self.button('tutorial','練習する',(118,482,84,44),self.begin_tutorial)
        self.button('records','記録',(210,482,82,44),self.show_records)
        topo=self.topologies[self.settings['board']]
        dimensions=f'{topo.spec.width}×{topo.spec.height}・' if topo.spec.width else ''
        self.text(f'{dimensions}{len(topo.cells)}マス・地雷{topo.spec.mines}個',((w+320)/2,100),18,align='center')
        self.draw_board(topo,(340,152,w-374,self.H-258))
        adj={'square':'上下左右と斜めの最大8マス','hex':'辺で接する最大6マス','triangle':'辺または頂点で接する最大12マス'}[topo.spec.shape]
        self.text(adj,((w+320)/2,self.H-76),16,MUTED,'center')
        if self.dropdown:
            # Overlay the selector; prevent click-through to controls under it.
            pygame.draw.rect(self.canvas,PANEL,(26,170,270,254),border_radius=6)
            self.buttons=[]
            for i,s in enumerate(SPECS):
                self.button('choose-'+s.key,s.name,(30,174+49*i,260,46),lambda key=s.key:self.choose_board(key),primary=s.key==self.settings['board'])

    def draw_play(self):
        session=self.session;game=session.game
        if session.paused:
            self.text('一時停止',(self.W/2,self.H/2-86),32,align='center')
            self.text(format_time(session.centiseconds(self.now)),(self.W/2,self.H/2-35),28,align='center')
            self.text('盤面とヒントを隠して計時を止めている．',(self.W/2,self.H/2+12),17,MUTED,'center')
            self.row([('resume','再開',self.resume,True,True),('rules','遊び方',self.show_rules,True,False),('leave','設定へ',self.leave,True,False)],self.H/2+62)
            return
        label='クリア！' if game.state=='won' else '地雷に当たった' if game.state=='lost' else game.topology.spec.name
        self.text(label,(26,78),22,GREEN if game.state=='won' else RED if game.state=='lost' else INK)
        self.text(format_time(session.centiseconds(self.now)),(self.W/2,73),28,align='center')
        self.text(f'旗 {len(game.flags)} / 地雷 {len(game.mines)}   ヒント {session.hint_count}回',(self.W-26,80),17,align='right')
        self.draw_board(game.topology,(26,126,self.W-52,self.H-306),game,True)
        if game.finished:
            items=[('again','同じ設定でもう一度',self.start,True,True),('leave','設定へ',self.leave,True,False),('records','記録',self.show_records,True,False)]
            message=self.record_message if game.state=='won' else '地雷と誤った旗を表示した．次は新しい配置で挑戦できる．'
            if game.state=='won':message+=f' ヒント{ "あり" if session.hint_count else "なし" }の記録．'
        else:
            items=[]
            if self.settings['control']=='switch':items.append(('flag','旗 ON・旗を付け外し' if self.flag_mode else '旗 OFF・開く',self.toggle_flag,True,self.flag_mode))
            else:self.text('左：開く ／ 右：旗',(self.W/2,self.H-169),14,MUTED,'center')
            items += [('hint','ヒント',self.hint,game.state=='playing',False),('pause','一時停止',self.pause,True,False),('rules','遊び方',self.show_rules,True,False),('leave','設定へ',self.leave,True,False)]
            message=session.message or '数字は周囲の地雷の数．地雷以外を全部開けばクリア．'
        self.row(items,self.H-146)
        pygame.draw.rect(self.canvas,(225,232,233),(24,self.H-89,self.W-48,62),border_radius=5)
        self.paragraph(message,(36,self.H-83,self.W-72,56),16)

    def draw_rules(self):
        self.text('遊び方',(30,88),26)
        text=('地雷でないマスをすべて開けばクリア．地雷を開くと失敗する．\n'
              '最初に開くマスにも地雷がある．旗を立てること自体はクリア条件ではない．\n'
              '数字は周囲にある地雷の数．0の領域は連続して開く．旗のあるマスは保護される．\n\n'
              '通常：上下左右・斜めの最大8マス／六角形：辺で接する最大6マス．\n'
              '三角形：辺または頂点で接する最大12マスを数える．\n\n'
              '左右クリック式：左で開く，右で旗．旗スイッチ式：OFFで開く，ONで旗．\n'
              '矢印：マス選択／Space：開く／F：旗／H：ヒント／P：一時停止．\n'
              'Tab：盤面・ボタン移動．ボタン上ではEnterまたはSpaceで決定する．\n\n'
              'ヒントは数字から分かる1マスと理由を示す．自分で開く・旗を置く．\n'
              '有効なヒントを使った局は「ヒントあり」の順位表へ．判断できない場合もある．\n'
              '一時停止・説明・離席中は盤面を隠して時計を止める．復帰後は「再開」を押す．')
        self.paragraph(text,(30,138,self.W-60,self.H-218),17)
        self.button('back','戻る',(self.W/2-70,self.H-65,140,44),self.back,primary=True)

    def draw_records(self):
        self.text('記録・上位10件',(30,88),26)
        def cycle():
            keys=list(BY_KEY);self.record_board=keys[(keys.index(self.record_board)+1)%len(keys)]
        self.button('record-board',BY_KEY[self.record_board].name+'  ⇄',(30,140,300,44),cycle)
        self.button('assisted','ヒントあり' if self.assisted else 'ヒントなし',(346,140,170,44),lambda:setattr(self,'assisted',not self.assisted))
        self.text('順位',(40,200),16,MUTED);self.text('日時',(120,200),16,MUTED)
        self.text('タイム',(self.W-290,200),16,MUTED);self.text('ヒント',(self.W-120,200),16,MUTED)
        records=self.saves.records(self.record_board,self.assisted)
        if not records:self.text('まだクリア記録がない．',(40,250),20,MUTED)
        for i,r in enumerate(records):
            y=234+i*min(32,(self.H-330)/10)
            stamp=datetime.fromisoformat(r['date']).astimezone().strftime('%Y/%m/%d %H:%M')
            self.text(i+1,(48,y),17);self.text(stamp,(120,y),17)
            self.text(format_time(r['time']),(self.W-290,y),17);self.text(r['hints'],(self.W-110,y),17)
        self.paragraph('この端末・保存先の記録．Windows版とブラウザ版は別保存．ブラウザデータの消去やプライベートブラウズでは記録が残らない場合がある．',(30,self.H-105,self.W-60,40),13,MUTED)
        self.button('back','戻る',(self.W/2-70,self.H-58,140,40),self.back,primary=True)

    def draw_confirm(self):
        self.text('このゲームを終了する？',(self.W/2,self.H/2-60),28,align='center')
        self.text('途中の盤面と時間は保存されない．',(self.W/2,self.H/2),18,MUTED,'center')
        quit_app=self.screen=='quit'
        def accept():
            if quit_app:self.running=False
            else:self.transition('setup','start')
        self.row([('cancel','戻る',self.return_to_play,True,True),('accept','終了する',accept,True,False)],self.H/2+52)

    def draw_tutorial(self):
        steps=[
            '1．金色の枠のマスを開いてみよう．',
            '2．「1」は周囲の8マスに地雷が1個あるという意味．「次へ」で旗を試そう．',
            '3．この練習では中央が地雷．金色のマスに旗を置こう．',
            '4．旗は同じ操作でもう一度外せる．中央の旗を外してみよう．',
            '練習完了．本番では数字を頼りに，安全なマスを探そう．',
        ]
        self.text('練習・記録には残らない',(28,82),23)
        target=6 if self.tutorial_step<2 else 12 if self.tutorial_step<4 else None
        self.draw_board(self.tutorial.topology,(self.W/2-150,136,300,min(300,self.H-300)),self.tutorial,True,target)
        self.paragraph(steps[self.tutorial_step],(30,self.H-140,self.W-60,60),18)
        items=[]
        if self.settings['control']=='switch':items.append(('flag','旗 ON・旗を付け外し' if self.flag_mode else '旗 OFF・開く',self.toggle_flag,True,self.flag_mode))
        if self.tutorial_step==1:items.append(('next','次へ',self.next_tutorial,True,True))
        items += [('restart','最初から',self.begin_tutorial,True,False),('end-tutorial','設定へ',lambda:self.transition('setup','start'),True,self.tutorial_step==4)]
        self.row(items,self.H-65)

    def draw(self):
        width,height=self.window.get_size()
        self.W=max(800,width);self.H=max(600,height)
        self.canvas=pygame.Surface((self.W,self.H));self.canvas.fill(BG)
        self.buttons=[];self.polygons=()
        pygame.draw.rect(self.canvas,PANEL,(0,0,self.W,62))
        pygame.draw.line(self.canvas,(203,210,213),(0,62),(self.W,62))
        self.text('マインスイーパー',(24,15),23)
        labels={'setup':'開始前の設定','play':'プレイ','rules':'遊び方','records':'記録','tutorial':'練習','confirm':'終了確認','quit':'終了確認','audio':'音の設定'}
        self.text(labels[self.screen],(self.W-24,21),15,MUTED,'right')
        if self.screen=='setup':self.draw_setup()
        elif self.screen=='play':self.draw_play()
        elif self.screen=='rules':self.draw_rules()
        elif self.screen=='records':self.draw_records()
        elif self.screen=='tutorial':self.draw_tutorial()
        elif self.screen=='audio':self.draw_audio()
        else:self.draw_confirm()
        if self.screen not in ('audio','confirm','quit') and not self.saves.error and not self.dropdown:
            self.button('audio','音の設定',(self.W-292,9,126,44),self.show_audio)
        if self.saves.error:
            pygame.draw.rect(self.canvas,(248,227,204),(0,0,self.W,62))
            self.text('未保存：記録・設定を保存できない',(20,8),18,RED)
            self.text('記録を失わないよう，保存先を確認して再試行する．',(20,34),13,INK)
            self.button('retry','保存を再試行',(self.W-176,9,160,44),self.retry_save,primary=True)
            if self.screen not in ('audio','confirm','quit') and not self.dropdown:
                self.button('audio','音の設定',(self.W-322,9,126,44),self.show_audio)
        scale=min(width/self.W,height/self.H)
        dest=(round(self.W*scale),round(self.H*scale));ox=(width-dest[0])//2;oy=(height-dest[1])//2
        self.window.fill(BG)
        self.window.blit(pygame.transform.smoothscale(self.canvas,dest),(ox,oy))
        self.last_transform=(scale,ox,oy)
        pygame.display.flip()
        active=self.screen=='play' and self.session.game.state in ('ready','playing') and not self.session.paused
        audible=self.window_focused and getattr(self.platform,'focused',lambda:True)()
        self.audio.set_active(audible and (active or (self.screen=='audio' and self.audio_preview)))
        self.platform.active(active)
        if not active:self.platform.painted()
        if self.check_mode:
            game=self.session.game if self.screen=='play' else self.tutorial if self.screen=='tutorial' else None
            visible=game is not None and bool(self.polygons)
            data={'screen':self.screen,'settings':self.settings,'size':[self.W,self.H],
                  'buttons':{key:list(rect) for key,rect,_,enabled in self.buttons if enabled},
                  'centers':[center(p) for p in self.polygons],
                  'state':game.state if game else None,
                  'numbers':list(game.public().numbers) if visible else [],
                  'flags':sorted(game.flags) if visible else [],
                  'paused':self.session.paused if self.session else False,
                  'time':self.session.centiseconds(self.now) if self.session else 0,
                  'hint':{'cell':self.session.hint.cell,'action':self.session.hint.action} if visible and self.screen=='play' and self.session.hint else None,
                  'error':self.saves.error,'tutorial_step':self.tutorial_step,
                  'audio':{'available':self.audio.available,'playing':self.audio.playing,'error':self.audio.error or self.audio.bgm_error},
                  'python':sys.version.split()[0],'pygame':pygame.version.ver}
            js_eval('window.__mineReport='+json.dumps(data,ensure_ascii=True))

    def event(self,event):
        if event.type==pygame.QUIT:self.close_request();return
        if event.type==pygame.WINDOWFOCUSLOST:
            self.window_focused=False;self.audio_preview=False;self.audio.suspend()
            if self.screen=='play':self.pause()
            return
        if event.type==pygame.WINDOWFOCUSGAINED:self.window_focused=True;return
        if event.type in (pygame.MOUSEBUTTONDOWN,pygame.KEYDOWN):self.audio.unlock()
        if event.type==pygame.MOUSEBUTTONDOWN and event.button in (1,3):
            scale,ox,oy=self.last_transform
            point=((event.pos[0]-ox)/scale,(event.pos[1]-oy)/scale)
            for key,rect,action,enabled in reversed(self.buttons):
                if rect.collidepoint(point):
                    if event.button==1 and enabled:self.focus=key;action()
                    return
            if self.dropdown:self.dropdown=False;return
            if self.screen in ('play','tutorial') and self.polygons:
                cell=hit(self.polygons,point)
                if cell is not None:
                    self.selected=cell;self.focus='board'
                    flag=event.button==3 if self.settings['control']=='mouse' else self.flag_mode
                    if self.settings['control']=='switch' and event.button==3:return
                    self.open_cell(cell,flag)
        elif event.type==pygame.KEYDOWN:
            if getattr(event,'repeat',False):return
            if event.key==pygame.K_TAB:
                keys=[b[0] for b in self.buttons if b[3]]
                if self.screen in ('play','tutorial') and self.polygons:keys.insert(0,'board')
                if keys:
                    index=keys.index(self.focus) if self.focus in keys else -1
                    self.focus=keys[(index+(-1 if event.mod & pygame.KMOD_SHIFT else 1))%len(keys)]
                return
            if event.key==pygame.K_ESCAPE:
                if self.dropdown:self.dropdown=False
                elif self.screen=='audio':self.back_audio()
                elif self.screen in ('rules','records'):self.back()
                elif self.screen in ('confirm','quit'):self.return_to_play()
                elif self.screen=='tutorial':self.transition('setup','start')
                elif self.screen=='play':self.pause()
                return
            if self.focus=='board' and self.screen in ('play','tutorial'):
                game=self.session.game if self.screen=='play' else self.tutorial
                if self.screen=='play' and (self.session.paused or game.finished):return
                directions={pygame.K_LEFT:(-1,0),pygame.K_RIGHT:(1,0),pygame.K_UP:(0,-1),pygame.K_DOWN:(0,1)}
                if event.key in directions:self.selected=game.topology.move(self.selected,*directions[event.key])
                elif event.key==pygame.K_SPACE:self.open_cell(self.selected)
                elif event.key==pygame.K_f:self.open_cell(self.selected,True)
                elif self.screen=='play' and event.key==pygame.K_h:self.hint()
                elif self.screen=='play' and event.key==pygame.K_p:self.pause()
            elif event.key in (pygame.K_RETURN,pygame.K_SPACE):
                for key,_,action,enabled in self.buttons:
                    if key==self.focus and enabled:action();return


def frames():
    app=App();clock=pygame.time.Clock();frames=0
    try:
        while app.running:
            app.now=app.platform.now()
            lost=app.platform.lost_at()
            if lost is not None and app.screen=='play':app.session.pause(lost);app.focus='resume'
            if app.platform.audio_lost():app.audio_preview=False;app.audio.suspend()
            if WEB:
                size=app.platform.size(app.window.get_size())
                if size!=app.window.get_size():app.window=pygame.display.set_mode(size,pygame.RESIZABLE)
            for event in pygame.event.get():app.event(event)
            app.draw()
            frames+=1
            if not WEB and '--smoke' in sys.argv and frames==5:
                captures=[a.partition('=')[2] for a in sys.argv if a.startswith('--capture=')]
                if captures:pygame.image.save(app.window,captures[0])
                app.running=False
            yield
            if not WEB:clock.tick(60)
    finally:app.audio.close();pygame.quit()


async def run():
    for _ in frames():
        await asyncio.sleep(0)


def run_native():
    # Desktop has no asynchronous I/O; avoid a needless loopback socket.
    for _ in frames():
        pass
