"""Minesweeper: shared Python rules for Windows and the browser."""
__version__ = '0.1.0'
