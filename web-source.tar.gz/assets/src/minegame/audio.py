"""Optional audio output. Game rules and saved records never depend on a device."""
from pathlib import Path
import pygame
from .storage import AUDIO_DEFAULTS


class Audio:
    EFFECTS=('open','flag_on','flag_off','hint','notice','win','lose')

    def __init__(self, folder, settings, mixer=None):
        self.folder=Path(folder)
        if mixer is None:
            from .platforms import WEB
            if WEB:
                from .web_audio import WebMixer
                mixer=WebMixer()
        self.mixer=mixer if mixer is not None else pygame.mixer
        self.settings={**AUDIO_DEFAULTS,**settings}
        self.attempted=False;self.available=False
        self.error='';self.bgm_error=''
        self.effects={};self.bgm=None;self.se_channel=None;self.bgm_channel=None
        self.wanted=False;self.started=False;self.playing=False

    def unlock(self, retry=False):
        if retry:
            self.close();self.attempted=False
        if self.attempted:return
        self.attempted=True;self.error='';self.bgm_error=''
        try:
            if not self.mixer.get_init():
                self.mixer.init(frequency=22050,size=-16,channels=2,buffer=512)
            self.mixer.set_num_channels(2)
            self.bgm_channel=self.mixer.Channel(0)
            self.se_channel=self.mixer.Channel(1)
            self.effects={key:self.mixer.Sound(str(self.folder/(key+'.wav'))) for key in self.EFFECTS}
            self.available=True
            try:self.bgm=self.mixer.Sound(str(self.folder/'bgm.wav'))
            except (pygame.error,OSError,ValueError):
                self.bgm=None;self.bgm_error='BGMを読み込めない．SEは利用できる．'
            self.configure(self.settings)
        except (pygame.error,OSError,ValueError):
            self._failed()

    def _failed(self):
        self.available=False;self.playing=False
        self.error='音声を利用できない．ゲームは続けられる．'
        for channel in (self.se_channel,self.bgm_channel):
            if channel:
                try:channel.stop()
                except pygame.error:pass

    def volume(self, kind):
        return 0 if self.settings[kind+'_muted'] else self.settings[kind+'_volume']/100

    def poll_error(self):
        if self.available and hasattr(self.mixer,'read_error'):
            self.error=self.mixer.read_error()

    def configure(self, settings):
        self.settings={**AUDIO_DEFAULTS,**settings}
        if not self.available:return
        try:
            self.se_channel.set_volume(self.volume('se'))
            if not self.volume('se'):self.se_channel.stop()
            self.bgm_channel.set_volume(self.volume('bgm'))
            self.set_active(self.wanted)
        except pygame.error:self._failed()

    def effect(self, key):
        if not self.available or not self.volume('se'):return
        try:
            self.se_channel.play(self.effects[key])
            # Channel.play resets volume, so apply it after every new sound.
            self.se_channel.set_volume(self.volume('se'))
        except pygame.error:self._failed()

    def set_active(self, active):
        self.wanted=bool(active)
        if not self.available or self.bgm is None:return
        should_play=self.wanted and self.volume('bgm')>0
        try:
            if should_play and not self.playing:
                if self.started:self.bgm_channel.unpause()
                else:
                    self.bgm_channel.play(self.bgm,loops=-1)
                    self.started=True
                self.bgm_channel.set_volume(self.volume('bgm'))
                self.playing=True
            elif not should_play and self.playing:
                self.bgm_channel.pause();self.playing=False
        except pygame.error:self._failed()

    def suspend(self):
        self.set_active(False)
        if self.available:
            try:self.se_channel.stop()
            except pygame.error:self._failed()

    def new_game(self):
        if self.available:
            try:self.bgm_channel.stop()
            except pygame.error:self._failed()
        self.wanted=False;self.started=False;self.playing=False

    def close(self):
        self.suspend();self.new_game();self.available=False
