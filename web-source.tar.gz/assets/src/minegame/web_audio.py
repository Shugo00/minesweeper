"""Two browser audio elements; bundled WAV bytes need no additional URL requests."""
import base64
import json
from pathlib import Path
from .platforms import js_eval,js_value


class WebChannel:
    def __init__(self,index):self.ref=f'window.__mineAudio.channels[{index}]'

    def play(self,sound,loops=0):
        js_eval(f'''(() => {{const a={self.ref};a.pause();
            a.src=window.__mineAudio.sounds[{json.dumps(sound)}];a.currentTime=0;
            a.loop={str(loops==-1).lower()};
            if(!document.hidden && document.hasFocus())a.play().catch(e=>{{if(e.name!=='AbortError')window.__mineAudio.error='音声を開始できない．音の設定から再試行できる．';}});
        }})()''')

    def set_volume(self,value):js_eval(self.ref+'.volume='+str(value))
    def pause(self):js_eval(self.ref+'.pause()')
    def unpause(self):
        js_eval(f'''if(!document.hidden && document.hasFocus()){{{self.ref}.play().catch(e=>{{if(e.name!=='AbortError')window.__mineAudio.error='音声を再開できない．音の設定から再試行できる．';}});}}''')
    def stop(self):js_eval(self.ref+'.pause();'+self.ref+'.currentTime=0')


class WebMixer:
    def __init__(self):self.ready=False
    def get_init(self):return self.ready
    def init(self,**kwargs):
        js_eval('''if(!window.__mineAudio){
            window.__mineAudio={channels:[new Audio(),new Audio()],sounds:{},error:'',lost:false};
            const stop=()=>{window.__mineAudio.lost=true;for(const a of window.__mineAudio.channels)a.pause();};
            window.addEventListener('blur',stop);
            document.addEventListener('visibilitychange',()=>{if(document.hidden)stop();});
        }''')
        self.ready=True
    def set_num_channels(self,count):
        assert count==2
        js_eval("window.__mineAudio.error=''")
    def Sound(self,path):
        key=Path(path).name
        data='data:audio/wav;base64,'+base64.b64encode(Path(path).read_bytes()).decode('ascii')
        js_eval('window.__mineAudio.sounds['+json.dumps(key)+']='+json.dumps(data))
        return key
    def Channel(self,index):return WebChannel(index)
    def read_error(self):return js_value('window.__mineAudio?.error || ""')
